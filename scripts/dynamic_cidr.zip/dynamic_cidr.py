import boto3
import cfnresponse

def handler( event, context ):
  return True